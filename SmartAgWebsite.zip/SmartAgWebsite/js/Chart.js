var data = document.getElementById("testData");




d3.text("src/testdata.csv", function(data) {
    var parsedCSV = d3.csv.parseRows(data);
    window.chartTimes = [1, 2, 3];
    window.chartHeights = [1, 2, 3];
    window.chartWater = [1, 2, 3];
    for (i = 0; i < parsedCSV.length; i++) {
        chartTimes.push(parsedCSV[i][0]);
        chartHeights.push(parsedCSV[i][1]);
        chartWater.push(parsedCSV[i][2]);
    }
    return parsedCSV;
    // console.log(chartTimes[400]);
})

// function parseCSV(parsedCSV) {
//     chartTimes = [];
//     chartHeights = [];
//     chartWater = [];
//     for (i = 0; i < parsedCSV.length; i++) {
//         chartTimes.push(parsedCSV[i][0]);
//         chartHeights.push(parsedCSV[i][1]);
//         chartWater.push(parsedCSV[i][2]);
//     }
//     return [chartTimes, chartHeights, chartWater];
}
// var chartTimes = [2,2,2];
// var chartHeights = [0.1,0.1,1];
// var chartWater = [0.3,3,4];

var ctx = document.getElementById("lineChart");
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: parseCSV()[0],
        datasets: [{
            label: 'Heights',
            data: parseCSV()[2],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});



// var ctx = document.getElementById('firstChart').getContext('2d');
// var chart = new Chart(ctx, {
//     // The type of chart we want to create
//     type: 'line',
//
//     // The data for our dataset
//     data: {
//         labels: ["January", "February", "March", "April", "May", "June", "July"],
//         datasets: [{
//             label: "Data Stuff",
//             backgroundColor: 'rgb(255, 99, 132)',
//             borderColor: 'rgb(255, 99, 132)',
//             data: [0, 10, 5, 2, 20, 30, 45],
//         }]
//     },
//
//     // Configuration options go here
//     options: {}
// });
