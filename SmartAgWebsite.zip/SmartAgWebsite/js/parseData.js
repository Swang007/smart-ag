var data = import('../src/testdata.csv');


