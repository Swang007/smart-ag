import csv

testdata = open(testdata.csv)